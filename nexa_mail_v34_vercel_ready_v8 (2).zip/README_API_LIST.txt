API List Explorer (V17)
- Menu baru: API List, terpisah di daftar fitur.
- Saat masuk, layar kunci bergaya iPhone meminta kode akses 1998.
- Katalog endpoint diambil dari https://www.api-xyurei.my.id/api/apilist
- Pilih endpoint untuk membuat form parameter dinamis, lalu tekan Eksekusi endpoint.
- Eksekusi dibatasi pada path endpoint yang terdaftar di katalog API List; host upstream dikunci ke api-xyurei.my.id.
- Netlify membutuhkan folder function/ dan netlify.toml.
- Kunci 1998 pada UI adalah pengunci antarmuka di sisi browser, bukan sistem autentikasi server yang kuat.
