(() => {
  const $ = id => document.getElementById(id);
  const form = $('detikSearchForm'); if (!form) return;
  const input = $('detikSearchInput'), button = $('detikSearchButton'), status = $('detikSearchStatus'), count = $('detikSearchCount'), list = $('detikNewsList');
  let requestNo = 0;
  const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const safeHttps = value => { try { const u = new URL(value); return u.protocol === 'https:' && (u.hostname === 'detik.com' || u.hostname.endsWith('.detik.com')) ? u.href : ''; } catch (_) { return ''; } };
  const safeImage = value => { try { const u = new URL(value); return u.protocol === 'https:' ? u.href : ''; } catch (_) { return ''; } };
  async function search(query) {
    query = String(query || '').trim(); if (!query) { status.textContent = 'Masukkan kata kunci berita.'; input.focus(); return; }
    const current = ++requestNo; button.disabled = true; button.textContent = 'Mencari…'; status.innerHTML = '<span class="detik-loading">Sedang mencari berita…</span>'; list.innerHTML = ''; count.textContent = 'Memuat hasil…';
    try {
      const response = await fetch('/api/detik-search?q=' + encodeURIComponent(query), { headers: { accept: 'application/json' }, cache: 'no-store' });
      const payload = await response.json(); if (current !== requestNo) return;
      if (!response.ok || payload.status !== true || !Array.isArray(payload.result)) throw new Error(payload.message || 'Pencarian Detik gagal.');
      const items = payload.result.filter(item => item && safeHttps(item.url));
      count.textContent = `${Number(payload.total) || items.length} berita`;
      status.textContent = items.length ? `Ditemukan ${items.length} hasil untuk “${query}”.` : `Tidak ada hasil untuk “${query}”.`;
      if (!items.length) { list.innerHTML = '<div class="detik-search-empty">Belum ada berita yang cocok. Coba kata kunci lain.</div>'; return; }
      list.innerHTML = items.map((item, i) => {
        const url = safeHttps(item.url), image = safeImage(item.image);
        const thumb = image ? `<img class="detik-news-thumb" src="${escapeHtml(image)}" alt="" loading="lazy" decoding="async" referrerpolicy="no-referrer" onerror="this.style.visibility='hidden'">` : '<div class="detik-news-thumb" aria-hidden="true"></div>';
        return `<article class="detik-news-card" style="animation-delay:${Math.min(i*35,350)}ms">${thumb}<div class="detik-news-copy"><span class="detik-news-category">${escapeHtml(item.category || 'Detik')}</span><h3 class="detik-news-title">${escapeHtml(item.title)}</h3><time class="detik-news-time">${escapeHtml(item.time || 'Waktu tidak tersedia')}</time><a class="detik-news-open" href="${escapeHtml(url)}" target="_blank" rel="noopener noreferrer">Baca artikel <span aria-hidden="true">↗</span></a></div></article>`;
      }).join('');
    } catch (error) { if (current !== requestNo) return; status.textContent = error.message || 'Pencarian gagal. Coba lagi.'; count.textContent = 'Pencarian gagal'; list.innerHTML = '<div class="detik-search-empty">Tidak dapat memuat berita saat ini. Periksa koneksi lalu coba lagi.</div>'; }
    finally { if (current === requestNo) { button.disabled = false; button.textContent = 'Cari ↗'; } }
  }
  form.addEventListener('submit', e => { e.preventDefault(); search(input.value); });
  $('detikSearchBack')?.addEventListener('click', () => window.go('home'));
})();
