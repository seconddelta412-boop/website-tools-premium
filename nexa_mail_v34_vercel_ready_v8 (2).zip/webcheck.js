/* Smooth Web Check interface — requests the same-origin /api/web-check proxy. */
(function () {
  'use strict';
  const $ = id => document.getElementById(id);
  const form = $('webcheckForm');
  if (!form) return;
  const statusEl = $('webcheckStatus'), resultsEl = $('webcheckResults'), submit = $('webcheckSubmit');
  let busy = false;
  const text = value => String(value === null || value === undefined || value === '' ? '—' : value);
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function safeLink(value) { try { const u = new URL(String(value || '')); return ['http:', 'https:'].includes(u.protocol) ? u.href : ''; } catch (_) { return ''; } }
  function row(label, value) { return `<div class="webcheck-data-row"><span>${esc(label)}</span><strong>${esc(text(value))}</strong></div>`; }
  function stat(label, value, hint) { return `<article class="webcheck-stat"><small>${esc(label)}</small><strong>${esc(text(value))}</strong><span>${esc(hint)}</span></article>`; }
  function panel(title, chip, body) { return `<section class="webcheck-panel"><div class="webcheck-panel-head"><h3>${esc(title)}</h3><span class="webcheck-chip">${esc(chip)}</span></div>${body}</section>`; }
  function render(data, scannedUrl) {
    const r = data.result || {};
    const links = Array.isArray(r.links) ? r.links : [];
    const images = Array.isArray(r.images) ? r.images : [];
    const assets = Array.isArray(r.assets) ? r.assets : [];
    const mobile = r.mobile_stats || {};
    const viewport = mobile.viewport || {};
    const canIndex = Number(r.isIndexable) === 1;
    const summary = `<div class="webcheck-summary">${stat('HTTP STATUS', r.httpStatusCode || data.code || '—', Number(r.httpStatusCode) >= 200 && Number(r.httpStatusCode) < 400 ? 'Server merespons baik' : 'Periksa respons server')}${stat('SEO INDEXABLE', canIndex ? 'Ya' : 'Tidak', canIndex ? 'Dapat diindeks mesin pencari' : 'Periksa aturan indexing')}${stat('OPQ SCORE', typeof r.opq === 'number' ? Math.round(r.opq) : r.opq, 'Skor yang dikembalikan API')}${stat('JUMLAH LINK', links.length, 'Tautan yang terdeteksi')}</div>`;
    const seo = row('Meta title', r.metaTitle) + row('Panjang title', r.metaTitleLength) + row('Meta description', r.metaDescription) + row('Bahasa', r.language) + row('Robots', r.robots || 'Tidak ditentukan') + row('Robots diizinkan', r.isRobotsAllowed ? 'Ya' : 'Tidak') + row('Canonical', r.canonicalTo || 'Tidak ditentukan') + row('Redirect', r.redirectTo || 'Tidak ada') + row('H1', r.h1) + row('Jumlah kata', r.countWords) + row('Charset', r.charset) + row('MIME', r.mime);
    const technical = row('URL dipindai', scannedUrl) + row('URL crawled', r.crawledUrl || '—') + row('File size', Number.isFinite(Number(r.fileSize)) ? `${Math.round(Number(r.fileSize) / 1024)} KB` : r.fileSize) + row('CSS', r.countCSS) + row('JavaScript', r.countJS) + row('W3C errors', r.w3cErrors) + row('W3C warnings', r.w3cWarnings) + row('Cookies', Array.isArray(r.cookies) ? r.cookies.length : r.countCookies) + row('Iframe', r.isUsingIframes ? 'Ada' : 'Tidak terdeteksi') + row('Passing juice', r.isPassingJuice ? 'Ya' : 'Tidak');
    const mobileBody = row('Viewport width', viewport.width) + row('Initial scale', viewport['initial-scale']) + row('Mobile optimized', mobile.mobile_optimized ? 'Ya' : 'Belum terdeteksi') + row('Handheld friendly', mobile.handheldfriendly ? 'Ya' : 'Belum terdeteksi') + row('Favicon', mobile.favicon ? 'Tersedia' : 'Tidak terdeteksi');
    const linkBody = links.length ? `<div class="webcheck-list">${links.slice(0, 30).map(item => { const href = safeLink(item.url); return `<a class="webcheck-link" ${href ? `href="${esc(href)}" target="_blank" rel="noopener noreferrer"` : ''}><strong>${esc(item.anchor || item.title || item.url || 'Tautan')}</strong><small>${esc(item.url || '')} · ${item.isInternal ? 'Internal' : 'Eksternal'}${item.isNofollow ? ' · nofollow' : ''}</small></a>`; }).join('')}</div>` : '<div class="webcheck-empty">Tidak ada tautan yang dikembalikan API.</div>';
    const imageBody = images.length ? `<div class="webcheck-list">${images.slice(0, 15).map(item => `<div class="webcheck-link"><strong>${esc(item.alt || item.title || 'Gambar')}</strong><small>${esc(item.url || '')}</small></div>`).join('')}</div>` : '<div class="webcheck-empty">Tidak ada gambar yang terdeteksi.</div>';
    const assetBody = assets.length ? `<div class="webcheck-list">${assets.slice(0, 15).map(item => `<div class="webcheck-link"><strong>${esc(item.type || 'Asset')}</strong><small>${esc(item.url || '')}</small></div>`).join('')}</div>` : '<div class="webcheck-empty">Tidak ada asset yang dikembalikan API.</div>';
    resultsEl.innerHTML = summary + panel('SEO & Metadata', 'SEO AUDIT', seo) + panel('Teknis Website', 'TECHNICAL', technical) + panel('Kesiapan Mobile', 'MOBILE', mobileBody) + panel('Tautan Ditemukan', `${links.length} LINKS`, linkBody) + panel('Gambar', `${images.length} IMAGES`, imageBody) + panel('Assets', `${assets.length} ASSETS`, assetBody);
    resultsEl.classList.remove('webcheck-hidden');
  }
  async function check() {
    if (busy) return;
    const input = $('webcheckUrl');
    let target; try { target = new URL(input.value.trim()); } catch (_) { statusEl.className = 'webcheck-status error'; statusEl.textContent = 'Masukkan URL lengkap, misalnya https://domainkamu.com'; input.focus(); return; }
    if (!['http:', 'https:'].includes(target.protocol) || target.username || target.password) { statusEl.className = 'webcheck-status error'; statusEl.textContent = 'URL harus menggunakan HTTP atau HTTPS dan tidak boleh berisi username/password.'; return; }
    busy = true; submit.disabled = true; submit.textContent = '◌  Sedang memeriksa…'; statusEl.className = 'webcheck-status loading'; statusEl.textContent = 'Menghubungi API Web Check dan menganalisis hasil…'; resultsEl.classList.add('webcheck-hidden'); resultsEl.replaceChildren();
    try {
      const endpoint = new URL('/api/web-check', window.location.origin); endpoint.searchParams.set('url', target.href);
      const response = await fetch(endpoint.href, { headers: { Accept: 'application/json' }, cache: 'no-store', signal: AbortSignal.timeout(30000) });
      const data = await response.json().catch(() => ({}));
      if (!response.ok || data.status !== true || !data.result) throw new Error(data.message || `Pemeriksaan gagal (HTTP ${response.status}).`);
      render(data, target.href); statusEl.className = 'webcheck-status'; statusEl.textContent = `Pemeriksaan selesai untuk ${target.hostname}. Hasil di bawah berasal dari API Web Check.`;
    } catch (error) {
      statusEl.className = 'webcheck-status error'; statusEl.textContent = (error && error.message) || 'Tidak dapat memeriksa website. Periksa koneksi lalu coba lagi.';
      resultsEl.innerHTML = '<div class="webcheck-empty">Belum ada hasil. Pastikan deploy Netlify menyertakan Function web-check dan redirect /api/web-check.</div>'; resultsEl.classList.remove('webcheck-hidden');
    } finally { busy = false; submit.disabled = false; submit.textContent = '✦  Periksa Website'; }
  }
  form.addEventListener('submit', event => { event.preventDefault(); check(); });
  $('webcheckBack')?.addEventListener('click', () => { if (typeof window.go === 'function') window.go('home'); else document.querySelectorAll('.screen').forEach(screen => screen.classList.toggle('active', screen.id === 'screen-home')); });
})();
