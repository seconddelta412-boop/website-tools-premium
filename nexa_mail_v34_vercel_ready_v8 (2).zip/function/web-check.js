// Server-side proxy for Xyurei Web Check. Keep the API key out of browser code.
const fetchImpl = global.fetch;
const API_KEY = process.env.WEB_CHECK_API_KEY || 'xyureifree-b1e0d';
exports.handler = async function (event) {
  if (event.httpMethod === 'OPTIONS') return json(204, { status: true });
  if (event.httpMethod !== 'GET') return json(405, { status: false, message: 'Method tidak didukung.' });
  const rawUrl = String((event.queryStringParameters || {}).url || '').trim();
  let target;
  try { target = new URL(rawUrl); } catch (_) { return json(400, { status: false, message: 'Masukkan URL website yang valid.' }); }
  if (!['http:', 'https:'].includes(target.protocol) || target.username || target.password || !target.hostname || target.hostname === 'localhost' || target.hostname.endsWith('.local')) {
    return json(400, { status: false, message: 'Gunakan URL website publik dengan protokol HTTP atau HTTPS.' });
  }
  if (rawUrl.length > 2048) return json(400, { status: false, message: 'URL terlalu panjang.' });
  try {
    const upstream = new URL('https://www.api-xyurei.my.id/api/tools/web-check');
    upstream.searchParams.set('apikey', API_KEY);
    upstream.searchParams.set('url', target.href);
    const response = await fetchImpl(upstream.href, { headers: { accept: 'application/json' }, signal: AbortSignal.timeout(25000), cache: 'no-store' });
    const raw = await response.text();
    let data; try { data = JSON.parse(raw); } catch (_) { return json(502, { status: false, message: 'API Web Check mengirim respons yang tidak valid.' }); }
    if (!response.ok || data.status !== true || !data.result || typeof data.result !== 'object') {
      return json(502, { status: false, message: data.message || `API Web Check gagal (HTTP ${response.status}).` });
    }
    return json(200, data);
  } catch (error) {
    return json(502, { status: false, message: error && error.name === 'TimeoutError' ? 'Pemeriksaan melewati batas waktu. Coba lagi.' : 'Tidak dapat terhubung ke API Web Check. Coba lagi beberapa saat.' });
  }
};
function json(statusCode, body) { return { statusCode, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'access-control-allow-origin': '*', 'access-control-allow-methods': 'GET,OPTIONS', 'access-control-allow-headers': 'Content-Type, Accept' }, body: JSON.stringify(body) }; }
