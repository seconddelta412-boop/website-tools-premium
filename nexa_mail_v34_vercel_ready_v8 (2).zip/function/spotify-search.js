// Netlify server-side proxy for Spotify search API.
const fetchImpl = global.fetch;
exports.handler = async function (event) {
  if (event.httpMethod !== 'GET') return json(405, { status: false, message: 'Method tidak didukung.' });
  const q = String((event.queryStringParameters || {}).q || '').trim().slice(0, 120);
  if (!q) return json(400, { status: false, message: 'Masukkan judul lagu atau artis.' });
  try {
    const url = new URL('https://www.api-xyurei.my.id/api/search/spotifysearch');
    // This API's search parameter is named query.
    url.searchParams.set('query', q);
    url.searchParams.set('apikey', process.env.XYUREI_API_KEY || 'xyureifree-b1e0d');
    const response = await fetchImpl(url.href, { headers: { accept: 'application/json' }, signal: AbortSignal.timeout(20000), cache: 'no-store' });
    const raw = await response.text();
    let data; try { data = JSON.parse(raw); } catch (_) { return json(502, { status: false, message: 'API musik mengirim respons bukan JSON.' }); }
    if (!response.ok) return json(502, { status: false, message: `API musik membalas HTTP ${response.status}.` });
    const tracks = data?.result?.tracks || data?.tracks || data?.result?.data?.tracks;
    if (!Array.isArray(tracks)) return json(502, { status: false, message: data?.message || 'Format respons API musik tidak sesuai.', debugKeys: Object.keys(data || {}) });
    return json(200, data);
  } catch (e) { return json(502, { status: false, message: e?.name === 'TimeoutError' ? 'API musik melewati batas waktu.' : 'Server tidak dapat terhubung ke API musik.' }); }
};
function json(statusCode, body) { return { statusCode, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' }, body: JSON.stringify(body) }; }
