// Server-side age-review workflow. No face photos or biometric data are collected.
const STORE_NAME = 'nexa-age-verification';
exports.handler = async (event) => {
  const method = event.httpMethod || 'GET';
  const qs = event.queryStringParameters || {};
  const adminKey = process.env.AGE_ADMIN_KEY;
  if (!adminKey) return json(503, { ok:false, message:'Admin belum dikonfigurasi. Set AGE_ADMIN_KEY di environment Netlify.' });
  let body = {};
  if (method === 'POST') { try { body = JSON.parse(event.body || '{}'); } catch { return json(400,{ok:false,message:'JSON tidak valid.'}); } }
  const action = String(qs.action || body.action || 'status');
  try {
    const { getStore } = await import('@netlify/blobs');
    const store = getStore(STORE_NAME);
    const userId = String(qs.userId || body.userId || '').slice(0,100);
    if (action === 'status' && method === 'GET') {
      if (!/^[a-f0-9-]{20,80}$/i.test(userId)) return json(400,{ok:false,message:'ID sesi tidak valid.'});
      const rec = await store.get(`user:${userId}`, { type:'json' });
      if (rec?.status === 'banned' && rec.banUntil && Date.parse(rec.banUntil) <= Date.now()) { rec.status = 'unverified'; rec.banUntil = null; rec.banReason = null; await store.setJSON(`user:${userId}`, rec); }
      const activeBan = rec?.status === 'banned' && (!rec.banUntil || Date.parse(rec.banUntil) > Date.now());
      return json(200,{ok:true,status:activeBan ? 'banned' : (rec?.status || 'unverified'),submittedAt:rec?.submittedAt || null,banUntil:activeBan ? (rec.banUntil || null) : null,banReason:activeBan ? (rec.banReason || 'Pelanggaran aturan usia') : null,permanent:activeBan && !rec.banUntil});
    }
    if (action === 'submit' && method === 'POST') {
      if (!/^[a-f0-9-]{20,80}$/i.test(userId)) return json(400,{ok:false,message:'ID sesi tidak valid.'});
      if (body.consent !== true) return json(400,{ok:false,message:'Persetujuan pemrosesan status diperlukan.'});
      if (body.adult !== true) {
        const priorUnderage = await store.get(`user:${userId}`, { type:'json' });
        const banHours = Math.max(1, Math.min(8760, Number(process.env.DEFAULT_AGE_BAN_HOURS || 24)));
        const rec = { userId, status:'banned', submittedAt:priorUnderage?.submittedAt || new Date().toISOString(), reviewedAt:new Date().toISOString(), banReason:'Pengguna menyatakan belum berusia 18 tahun', banUntil:new Date(Date.now()+banHours*3600000).toISOString() };
        await store.setJSON(`user:${userId}`, rec);
        return json(200,{ok:true,status:'banned',banUntil:rec.banUntil,message:'Akses diblokir sementara karena usia di bawah 18 tahun.'});
      }
      const prior = await store.get(`user:${userId}`, { type:'json' });
      if (prior?.status === 'approved') return json(200,{ok:true,status:'approved'});
      const rec = { userId, status:'pending', submittedAt:new Date().toISOString(), reviewedAt:null };
      await store.setJSON(`user:${userId}`, rec);
      return json(200,{ok:true,status:'pending',message:'Permintaan tercatat. Akses menunggu pemeriksaan admin.'});
    }
    if (action === 'admin-list' && method === 'GET') {
      if (event.headers?.['x-admin-key'] !== adminKey) return json(401,{ok:false,message:'Kunci admin salah.'});
      const listed = await store.list({ prefix:'user:' });
      const records = [];
      for (const item of (listed.blobs || [])) { const rec = await store.get(item.key,{type:'json'}); if(rec) records.push(rec); }
      records.sort((a,b)=>String(b.submittedAt).localeCompare(String(a.submittedAt)));
      return json(200,{ok:true,records});
    }
    if (action === 'ban' && method === 'POST') {
      if (event.headers?.['x-admin-key'] !== adminKey) return json(401,{ok:false,message:'Kunci admin salah.'});
      if (!/^[a-f0-9-]{20,80}$/i.test(userId)) return json(400,{ok:false,message:'ID sesi tidak valid.'});
      const hours = body.permanent === true ? null : Number(body.hours);
      if (hours !== null && (!Number.isFinite(hours) || hours < 1 || hours > 8760)) return json(400,{ok:false,message:'Durasi ban harus 1–8760 jam atau pilih permanen.'});
      const rec = await store.get(`user:${userId}`,{type:'json'}) || {userId,submittedAt:new Date().toISOString()};
      rec.status='banned'; rec.banReason=String(body.reason || 'Diblokir oleh admin').slice(0,300); rec.banUntil=hours===null?null:new Date(Date.now()+hours*3600000).toISOString(); rec.reviewedAt=new Date().toISOString();
      await store.setJSON(`user:${userId}`,rec);
      return json(200,{ok:true,status:'banned',banUntil:rec.banUntil,permanent:hours===null});
    }
    if (action === 'unban' && method === 'POST') {
      if (event.headers?.['x-admin-key'] !== adminKey) return json(401,{ok:false,message:'Kunci admin salah.'});
      if (!/^[a-f0-9-]{20,80}$/i.test(userId)) return json(400,{ok:false,message:'ID sesi tidak valid.'});
      const rec = await store.get(`user:${userId}`,{type:'json'}); if(!rec) return json(404,{ok:false,message:'Pengguna tidak ditemukan.'});
      rec.status='rejected'; rec.banUntil=null; rec.banReason=null; rec.reviewedAt=new Date().toISOString(); await store.setJSON(`user:${userId}`,rec); return json(200,{ok:true,status:rec.status});
    }
    if (action === 'review' && method === 'POST') {
      if (event.headers?.['x-admin-key'] !== adminKey) return json(401,{ok:false,message:'Kunci admin salah.'});
      if (!/^[a-f0-9-]{20,80}$/i.test(userId) || !['approved','rejected'].includes(body.status)) return json(400,{ok:false,message:'Permintaan review tidak valid.'});
      const rec = await store.get(`user:${userId}`,{type:'json'});
      if (!rec) return json(404,{ok:false,message:'Permintaan tidak ditemukan.'});
      rec.status = body.status; rec.reviewedAt = new Date().toISOString();
      await store.setJSON(`user:${userId}`,rec);
      return json(200,{ok:true,status:rec.status});
    }
    return json(405,{ok:false,message:'Action atau metode tidak didukung.'});
  } catch (e) {
    console.error('age-verification error',e);
    return json(503,{ok:false,message:'Penyimpanan verifikasi tidak tersedia. Aktifkan Netlify Blobs dan deploy ulang.'});
  }
};
function json(statusCode, body) { return { statusCode, headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'}, body:JSON.stringify(body) }; }
