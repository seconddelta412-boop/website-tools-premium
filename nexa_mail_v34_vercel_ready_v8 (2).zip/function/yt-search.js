// Netlify Function: server-side proxy untuk YouTube Search NexaDev API.
// Endpoint publik: /.netlify/functions/yt-search?q=karna%20kamu
const fetchImpl = global.fetch;
exports.handler = async function (event) {
  if (event.httpMethod === 'OPTIONS') return json(204, { status: true });
  if (event.httpMethod !== 'GET') return json(405, { status: false, message: 'Method tidak didukung.' });
  const query = String((event.queryStringParameters || {}).q || '').trim();
  if (!query) return json(400, { status: false, message: 'Parameter q wajib diisi.' });
  if (query.length > 200) return json(400, { status: false, message: 'Kata kunci terlalu panjang.' });
  try {
    const upstream = new URL('https://api.nexadev.my.id/tools/ytsearch');
    upstream.searchParams.set('q', query);
    const response = await fetchImpl(upstream.href, {
      headers: { accept: 'application/json' },
      signal: AbortSignal.timeout(20000),
      cache: 'no-store'
    });
    const raw = await response.text();
    let data;
    try { data = JSON.parse(raw); }
    catch (_) { return json(502, { status: false, message: 'API YouTube Search mengembalikan respons yang tidak valid.' }); }
    if (!response.ok) return json(response.status >= 400 && response.status < 600 ? response.status : 502, { status: false, message: 'API YouTube Search sedang tidak tersedia.' });
    if (data.status !== true || !Array.isArray(data.result)) return json(502, { status: false, message: 'Format respons API YouTube Search tidak sesuai.' });
    return json(200, data);
  } catch (_) {
    return json(502, { status: false, message: 'Tidak dapat terhubung ke API YouTube Search.' });
  }
};
function json(statusCode, body) {
  return { statusCode, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'access-control-allow-origin': '*', 'access-control-allow-methods': 'GET,OPTIONS', 'access-control-allow-headers': 'Content-Type, Accept' }, body: JSON.stringify(body) };
}
