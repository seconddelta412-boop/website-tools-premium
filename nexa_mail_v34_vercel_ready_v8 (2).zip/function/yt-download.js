// Server-side proxy for the NexaDev YouTube media endpoint.
const fetchImpl = global.fetch;
exports.handler = async function(event) {
  if (event.httpMethod === 'OPTIONS') return json(204, { status: true });
  if (event.httpMethod !== 'GET') return json(405, { status: false, message: 'Method tidak didukung.' });
  const params = event.queryStringParameters || {};
  const videoUrl = String(params.url || '').trim();
  const type = String(params.type || 'video').toLowerCase();
  const quality = String(params.quality || '720p').toLowerCase();
  let parsed;
  try { parsed = new URL(videoUrl); } catch (_) { return json(400, { status: false, message: 'Masukkan URL YouTube yang valid.' }); }
  if (!['youtube.com','www.youtube.com','m.youtube.com','youtu.be','www.youtu.be'].includes(parsed.hostname) || !['http:','https:'].includes(parsed.protocol)) return json(400, { status: false, message: 'URL harus berasal dari YouTube atau youtu.be.' });
  if (!['video','audio'].includes(type)) return json(400, { status: false, message: 'Tipe media harus video atau audio.' });
  if (!['360p','720p','1080p'].includes(quality)) return json(400, { status: false, message: 'Kualitas harus 360p, 720p, atau 1080p.' });
  const upstream = new URL('https://api.nexadev.my.id/api/ytmp4');
  upstream.searchParams.set('url', parsed.href); upstream.searchParams.set('type', type); upstream.searchParams.set('quality', quality);
  try {
    const response = await fetchImpl(upstream.href, { headers: { accept: 'application/json' }, signal: AbortSignal.timeout(45000), cache: 'no-store' });
    const raw = await response.text(); let payload;
    try { payload = JSON.parse(raw); } catch (_) { return json(502, { status: false, message: 'API downloader mengirim respons yang bukan JSON.' }); }
    if (!response.ok || payload.status !== true || !payload.data || !payload.data.url) return json(502, { status: false, message: payload.message || `API downloader gagal (HTTP ${response.status}).` });
    let downloadUrl;
    try { downloadUrl = new URL(payload.data.url); } catch (_) { return json(502, { status: false, message: 'Tautan unduhan dari API tidak valid.' }); }
    if (downloadUrl.protocol !== 'https:') return json(502, { status: false, message: 'Tautan unduhan tidak aman.' });
    return json(200, payload);
  } catch (error) {
    const timeout = error && (error.name === 'TimeoutError' || error.name === 'AbortError');
    return json(502, { status: false, message: timeout ? 'API downloader terlalu lama merespons. Coba lagi.' : 'Tidak dapat terhubung ke API downloader.' });
  }
};
function json(statusCode, body) { return { statusCode, headers: { 'content-type':'application/json; charset=utf-8', 'cache-control':'no-store, max-age=0', 'access-control-allow-origin':'*', 'access-control-allow-methods':'GET,OPTIONS', 'access-control-allow-headers':'Content-Type, Accept' }, body: JSON.stringify(body) }; }
