// Allowlisted proxy for Nexa utility APIs. API key is configured server-side.
const BASE = 'https://www.api-xyurei.my.id';
const MAX_IMAGE = 12 * 1024 * 1024;
const MAX_VIDEO = 35 * 1024 * 1024;

exports.handler = async (event) => {
  if (event.httpMethod !== 'GET') return out(405, { status: false, message: 'Method tidak didukung.' });
  const p = event.queryStringParameters || {};
  const action = String(p.action || '');
  const key = process.env.XYUREI_API_KEY || 'xyureifree-b1e0d';
  const specs = {
    translate: { path: '/api/tools/google-translate', params: { text: limit(p.text, 1500), mode: 'text-to-text', from: limit(p.from || 'auto', 20), to: limit(p.to || 'en', 30), apikey: key } },
    meme: { path: '/api/search/meme-search', params: { query: limit(p.query, 100), limit: String(Math.max(1, Math.min(12, Number(p.limit) || 6))), apikey: key } },
    quran: { path: '/api/islam/listsurah', params: { apikey: key } },
    shalat: { path: '/api/islam/bacaanshalat', params: { apikey: key } },
    kabupaten: { path: '/api/game/tebakkabupaten', params: { apikey: key } },
    tobrut: { path: '/api/random/tobrut', params: { apikey: key }, binary: 'video' },
    ssweb: { path: '/api/tools/ssweb', params: { url: validWebUrl(p.url), device: 'desktop', apikey: key }, binary: 'image' },
    ytplay: { path: '/api/search/ytplay', params: { query: limit(p.query, 160), apikey: key } },
    iqc: { path: '/api/maker/iqc', params: { text: limit(p.text, 500), apikey: key }, binary: 'image' }
  };
  const spec = specs[action];
  if (!spec) return out(400, { status: false, message: 'Action tidak dikenal.' });
  if (['translate', 'iqc'].includes(action) && !p.text) return out(400, { status: false, message: 'Parameter teks wajib diisi.' });
  if (action === 'meme' && !p.query) return out(400, { status: false, message: 'Parameter pencarian wajib diisi.' });
  if (action === 'ytplay' && !p.query) return out(400, { status: false, message: 'Masukkan judul lagu atau video.' });
  if (action === 'ssweb' && !spec.params.url) return out(400, { status: false, message: 'URL website tidak valid.' });
  try {
    const u = new URL(spec.path, BASE);
    Object.entries(spec.params).forEach(([k, v]) => { if (v !== undefined && v !== null && v !== '') u.searchParams.set(k, v); });
    const response = await fetch(u.href, {
      headers: { accept: spec.binary === 'image' ? 'image/png, image/jpeg, application/json' : spec.binary === 'video' ? 'video/mp4, video/webm, video/*, application/json' : 'application/json' },
      signal: AbortSignal.timeout(25000), cache: 'no-store'
    });
    if (!response.ok) return out(502, { status: false, message: `API sumber membalas HTTP ${response.status}.` });
    const contentType = (response.headers.get('content-type') || '').toLowerCase();
    if (spec.binary === 'image' && contentType.startsWith('image/')) {
      const bytes = Buffer.from(await response.arrayBuffer());
      if (!bytes.length || bytes.length > MAX_IMAGE) return out(502, { status: false, message: 'Gambar kosong atau terlalu besar.' });
      return binaryOut(contentType, bytes, action === 'iqc' ? 'nexa-iqc.png' : 'screenshot-web.png');
    }
    if (spec.binary === 'video' && (contentType.startsWith('video/') || contentType === 'application/octet-stream')) {
      const bytes = Buffer.from(await response.arrayBuffer());
      if (!bytes.length || bytes.length > MAX_VIDEO) return out(502, { status: false, message: 'Video kosong atau melebihi batas 35 MB.' });
      return binaryOut(contentType.startsWith('video/') ? contentType : 'video/mp4', bytes, 'nexa-random-video.mp4');
    }
    const raw = await response.text();
    let data;
    try { data = JSON.parse(raw); } catch { return out(502, { status: false, message: 'Respons API bukan JSON atau format media tidak didukung.' }); }
    if (spec.binary === 'video' && data && typeof data === 'object') {
      const mediaUrl = data.url || data.result?.url || data.result?.video || data.data?.url || data.data?.video;
      if (typeof mediaUrl === 'string' && /^https?:\/\//i.test(mediaUrl)) return { statusCode: 302, headers: { Location: mediaUrl, 'Cache-Control': 'no-store' }, body: '' };
    }
    if (spec.binary && data && data.info && String(data.info).startsWith('image/')) {
      return out(502, { status: false, message: 'API mengembalikan metadata gambar, bukan data gambar. Periksa respons endpoint.' });
    }
    return out(200, data);
  } catch (e) {
    return out(502, { status: false, message: e.name === 'TimeoutError' ? 'API melewati batas waktu. Coba lagi.' : 'Tidak dapat menghubungi API sumber.' });
  }
};
function validWebUrl(value) {
  try { const u = new URL(String(value || '')); return ['http:', 'https:'].includes(u.protocol) ? u.href : ''; }
  catch { return ''; }
}
function limit(v, n) { return String(v || '').trim().slice(0, n); }
function out(statusCode, body) { return { statusCode, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'access-control-allow-origin': '*' }, body: JSON.stringify(body) }; }
function binaryOut(type, bytes, filename) { return { statusCode: 200, headers: { 'content-type': type, 'content-disposition': `inline; filename="${filename}"`, 'cache-control': 'no-store', 'access-control-allow-origin': '*' }, isBase64Encoded: true, body: bytes.toString('base64') }; }
