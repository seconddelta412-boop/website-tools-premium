# AM Premium frontend integration

The AM Premium UI now sends JSON POST requests to your own backend routes:

- `POST /api/am/send` with `{ "email": "user@example.com" }`
- `POST /api/am/verif` with `{ "email": "user@example.com", "link": "https://..." }`

The backend should validate the user's authorization, validate input, rate-limit requests, and keep provider API credentials in server environment variables. Do not put API keys in HTML/JavaScript or commit them to this package. Never log full verification links: they can contain one-time authentication tokens.

The HTML intentionally does not call the third-party provider directly. Implement these routes on a server you control and only connect an API you are authorized to use for the relevant account/service. When routes are not configured, the UI will show a connection error rather than pretending the request succeeded.
