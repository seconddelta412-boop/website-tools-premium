// Server-side proxy for Xyurei flag guessing game API.
exports.handler = async function (event) {
  if (event.httpMethod === 'OPTIONS') return json(204, { status: true });
  if (event.httpMethod !== 'GET') return json(405, { status: false, message: 'Method tidak didukung.' });
  try {
    const upstream = 'https://www.api-xyurei.my.id/api/game/tebakbenderav1';
    const response = await fetch(upstream, { headers: { accept: 'application/json' }, signal: AbortSignal.timeout(15000), cache: 'no-store' });
    let data;
    try { data = await response.json(); } catch (_) { return json(502, { status: false, message: 'API game mengirim respons yang tidak valid.' }); }
    const item = data && data.result;
    if (!response.ok || data.status !== true || !item || typeof item.name !== 'string' || typeof item.img !== 'string') {
      return json(502, { status: false, message: data.message || `API game tidak tersedia (HTTP ${response.status}).` });
    }
    let image;
    try { image = new URL(item.img); } catch (_) { return json(502, { status: false, message: 'URL gambar bendera dari API tidak valid.' }); }
    if (image.protocol !== 'https:') return json(502, { status: false, message: 'Gambar bendera harus menggunakan HTTPS.' });
    return json(200, { status: true, creator: data.creator || 'Xyurei', result: { flag: String(item.flag || ''), img: image.href, name: item.name.trim() } });
  } catch (error) {
    return json(502, { status: false, message: error && error.name === 'TimeoutError' ? 'Server game terlalu lama merespons. Coba lagi.' : 'Tidak dapat terhubung ke API game. Coba lagi beberapa saat.' });
  }
};
function json(statusCode, body) { return { statusCode, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'access-control-allow-origin': '*', 'access-control-allow-methods': 'GET,OPTIONS', 'access-control-allow-headers': 'Content-Type, Accept' }, body: JSON.stringify(body) }; }
