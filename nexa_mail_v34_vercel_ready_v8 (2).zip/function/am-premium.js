// Netlify Function: kirim permintaan verifikasi AM.
// Gunakan NEXADEV_API_KEY pada Environment Variables. Jika belum diatur, paket memakai key yang diberikan pemilik proyek sebagai fallback server-side.
const fetchImpl = global.fetch;
exports.handler = async function (event) {
  if (event.httpMethod === 'OPTIONS') return json(204, { status: true });
  if (!['GET', 'POST'].includes(event.httpMethod)) return json(405, { status: false, message: 'Method tidak didukung.' });
  const q = { ...(event.queryStringParameters || {}), ...parseBody(event) };
  const email = String(q.email || '').trim();
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return json(400, { status: false, message: 'Email tujuan tidak valid.' });
  const key = process.env.NEXADEV_API_KEY || 'RS-ykD!d#35';
  
  try {
    const u = new URL('https://api.nexadev.my.id/am/send/');
    u.searchParams.set('key', key); u.searchParams.set('email', email);
    const r = await fetchImpl(u, { headers: { accept: 'application/json' }, signal: AbortSignal.timeout(30000), cache: 'no-store' });
    const raw = await r.text(); let data;
    try { data = JSON.parse(raw); } catch (_) { return json(502, { status: false, message: 'API upstream mengembalikan respons yang tidak valid.' }); }
    return json(r.ok ? (Number(data.statusCode) || 200) : r.status, data);
  } catch (_) { return json(502, { status: false, message: 'Tidak dapat terhubung ke API AM.' }); }
};
function parseBody(event) { if (!event.body) return {}; try { const b = JSON.parse(event.body); return b && typeof b === 'object' ? b : {}; } catch (_) { return {}; } }
function json(statusCode, body) { return { statusCode, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'access-control-allow-origin': '*', 'access-control-allow-methods': 'GET,POST,OPTIONS', 'access-control-allow-headers': 'Content-Type, Accept' }, body: JSON.stringify(body) }; }
