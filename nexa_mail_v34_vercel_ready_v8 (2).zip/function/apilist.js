const BASE = 'https://www.api-xyurei.my.id';
exports.handler = async (event) => {
  if (event.httpMethod !== 'GET') return json(405, {status:false,message:'Gunakan metode GET.'});
  const qs = event.queryStringParameters || {};
  const action = String(qs.action || 'list');
  try {
    if (action === 'list') {
      const r = await fetch(`${BASE}/api/apilist`, {headers:{accept:'application/json'},signal:AbortSignal.timeout(20000),cache:'no-store'});
      const data = await r.json();
      if (!r.ok || !Array.isArray(data.categories)) return json(502,{status:false,message:'API List tidak tersedia atau respons tidak valid.'});
      return json(200,data);
    }
    if (action === 'execute') {
      const path = String(qs.path || '');
      if (!/^\/api\/[a-zA-Z0-9/_-]+$/.test(path) || path.includes('..')) return json(400,{status:false,message:'Path endpoint tidak valid.'});
      const catalogResponse = await fetch(`${BASE}/api/apilist`,{headers:{accept:'application/json'},signal:AbortSignal.timeout(15000),cache:'no-store'});
      const catalog = await catalogResponse.json();
      const endpoint = (catalog.categories || []).flatMap(c=>c.items || []).find(item=>item.path===path);
      if (!endpoint) return json(403,{status:false,message:'Endpoint tidak ditemukan di API List.'});
      const allowed = new Set(Object.keys(endpoint.params || {}));
      const upstream = new URL(path, BASE);
      for (const [key,value] of Object.entries(qs)) {
        if (['action','path'].includes(key) || !allowed.has(key)) continue;
        if (typeof value === 'string' && value.length <= 2000) upstream.searchParams.set(key,value);
      }
      if (!upstream.searchParams.has('apikey')) upstream.searchParams.set('apikey',process.env.XYUREI_API_KEY || 'xyureifree-b1e0d');
      const r = await fetch(upstream.href,{headers:{accept:'application/json'},signal:AbortSignal.timeout(25000),cache:'no-store'});
      const raw = await r.text(); let data; try { data=JSON.parse(raw); } catch { data={raw:raw.slice(0,12000)}; }
      return json(r.ok?200:502,{httpStatus:r.status,endpoint:path,result:data});
    }
    return json(400,{status:false,message:'Action tidak dikenal.'});
  } catch (e) { return json(502,{status:false,message:e.name==='TimeoutError'?'API timeout. Coba lagi.':'Gagal menghubungi API Xyurei.'}); }
};
function json(statusCode, body){return {statusCode,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store','access-control-allow-origin':'*'},body:JSON.stringify(body)}}
