// Server-side Anime Indo proxy with multiple upstreams and response-shape normalization.
const fetchImpl = global.fetch;
const UPSTREAMS = [
  { url: 'https://api.nexadev.my.id/anime', kind: 'nexadev' },
  { url: 'https://apii.nexadev.my.id/anime', kind: 'nexadev' },
  { url: 'https://kumanime.vercel.app/api/latest', kind: 'kumanime' }
];

exports.handler = async function (event) {
  if (event.httpMethod === 'OPTIONS') return json(204, { success: true });
  if (event.httpMethod !== 'GET') return json(405, { success: false, message: 'Method tidak didukung.' });
  const params = event.queryStringParameters || {};
  const page = Math.max(1, Math.min(500, Number.parseInt(params.page || '1', 10) || 1));
  const q = String(params.q || '').trim().toLowerCase().slice(0, 80);
  const failures = [];

  for (const item of UPSTREAMS) {
    try {
      const upstream = new URL(item.url);
      if (item.kind === 'nexadev') {
        upstream.searchParams.set('recent', '1');
        upstream.searchParams.set('page', String(page));
      } else {
        upstream.searchParams.set('page', String(page));
      }
      const response = await fetchImpl(upstream.href, {
        headers: { accept: 'application/json', 'user-agent': 'Mozilla/5.0 NexaAnime/2.0' },
        signal: AbortSignal.timeout(10000), cache: 'no-store'
      });
      const raw = await response.text();
      let payload;
      try { payload = JSON.parse(raw); } catch (_) { failures.push(`${new URL(item.url).hostname}: respons bukan JSON`); continue; }
      if (!response.ok || payload?.success === false || payload?.status === false) {
        failures.push(`${new URL(item.url).hostname}: HTTP ${response.status}`); continue;
      }
      const normalized = normalize(payload, page, item.kind);
      if (q) normalized.animeList = normalized.animeList.filter(a => String(a.title || '').toLowerCase().includes(q));
      if (!normalized.animeList.length) { failures.push(`${new URL(item.url).hostname}: daftar kosong/tidak dikenali`); continue; }
      return json(200, { success: true, source: item.kind === 'kumanime' ? 'Kumanime · fallback' : (payload.source || payload.creator || 'Anime Indo API'), data: normalized });
    } catch (error) {
      failures.push(`${new URL(item.url).hostname}: ${error && error.name === 'TimeoutError' ? 'timeout' : 'koneksi HTTPS gagal'}`);
    }
  }
  return json(502, {
    success: false,
    message: 'Semua server Anime Indo sedang tidak bisa dihubungi. Tekan Coba lagi beberapa saat lagi.',
    details: failures
  });
};

function normalize(payload, page, kind) {
  const root = payload && typeof payload === 'object' ? payload : {};
  const d = root.data;
  const dataRoot = d && !Array.isArray(d) && typeof d === 'object' ? d : root;
  let list = [];
  const candidates = [
    root, root.animeList, root.result, root.results, root.latest, root.latestAnime,
    root.latest_release, root.latestRelease, root.ongoing_anime,
    Array.isArray(d) ? d : null,
    dataRoot.animeList, dataRoot.result, dataRoot.results, dataRoot.items, dataRoot.list,
    dataRoot.latest, dataRoot.latest_release, dataRoot.latestRelease, dataRoot.ongoing_anime,
    root.data?.animeList, root.data?.items, root.data?.list
  ];
  list = candidates.find(Array.isArray) || [];
  // Some APIs wrap the list in a nested object.
  if (!list.length && Array.isArray(root.data?.latest)) list = root.data.latest;
  const animeList = list.map((item) => {
    const a = item && typeof item === 'object' ? item : {};
    let link = a.link || a.url || a.animeUrl || a.href || a.animeLink || a.endpoint || a.animeId || a.slug || '';
    if (typeof link === 'string' && link.startsWith('/') && kind === 'kumanime') link = 'https://kumanime.vercel.app' + link;
    const image = a.image || a.poster || a.thumbnail || a.thumb || a.cover || a.img || a.imageUrl || '';
    const typeList = a.typeList && typeof a.typeList === 'object' ? Object.values(a.typeList).filter(Boolean).join(' · ') : '';
    return {
      ...a,
      title: String(a.title || a.name || a.judul || a.animeTitle || 'Anime tanpa judul'),
      image: String(image || ''),
      link: String(link || ''),
      type: String(a.type || a.category || a.statusType || a.status || typeList || 'Anime'),
      latestEpisode: String(a.latestEpisode || a.episode || a.latest_episode || a.episodeTitle || a.latest || a.release || a.upload_on || 'Episode terbaru')
    };
  }).filter(a => a.title !== 'Anime tanpa judul' || a.image || a.link);
  const total = Number(dataRoot.total || root.total || root.count || root.total_items) || animeList.length;
  const totalPages = Number(dataRoot.totalPages || dataRoot.total_pages || root.totalPages || root.total_pages || root.last_page) || Math.max(page, 1);
  return { animeList, total, totalPages, page };
}

function json(statusCode, body) {
  return { statusCode, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store, max-age=0', 'access-control-allow-origin': '*', 'access-control-allow-methods': 'GET,OPTIONS', 'access-control-allow-headers': 'Content-Type, Accept' }, body: JSON.stringify(body) };
}
