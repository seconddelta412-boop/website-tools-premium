// Server-side proxy for Detik search API.
exports.handler = async function (event) {
  if (event.httpMethod === 'OPTIONS') return json(204, { status: true });
  if (event.httpMethod !== 'GET') return json(405, { status: false, message: 'Method tidak didukung.' });
  const q = String((event.queryStringParameters || {}).q || '').trim();
  if (!q) return json(400, { status: false, message: 'Masukkan kata kunci berita.' });
  if (q.length > 120) return json(400, { status: false, message: 'Kata kunci terlalu panjang.' });
  try {
    const upstream = new URL('https://www.api-xyurei.my.id/api/news/detiksearch');
    upstream.searchParams.set('apikey', process.env.XYUREI_API_KEY || 'xyureifree-b1e0d');
    upstream.searchParams.set('q', q);
    const response = await fetch(upstream.href, { headers: { accept: 'application/json' }, signal: AbortSignal.timeout(20000), cache: 'no-store' });
    let data; try { data = await response.json(); } catch (_) { return json(502, { status: false, message: 'API Detik mengirim respons tidak valid.' }); }
    if (!response.ok || data.status !== true || !Array.isArray(data.result)) return json(502, { status: false, message: data.message || `API Detik gagal (HTTP ${response.status}).` });
    const result = data.result.filter(x => x && typeof x.title === 'string' && typeof x.url === 'string').map(x => {
      let url = ''; try { const u = new URL(x.url); if (u.protocol === 'https:' && (u.hostname === 'detik.com' || u.hostname.endsWith('.detik.com'))) url = u.href; } catch (_) {}
      let image = ''; try { const u = new URL(x.image || ''); if (u.protocol === 'https:') image = u.href; } catch (_) {}
      return { no: Number(x.no) || 0, title: String(x.title).slice(0, 400), time: String(x.time || '' ).slice(0, 100), url, image, category: String(x.category || 'Detik').slice(0, 80) };
    }).filter(x => x.url).slice(0, 50);
    return json(200, { status: true, creator: String(data.creator || ''), total: Number(data.total) || result.length, result });
  } catch (error) { return json(502, { status: false, message: error && error.name === 'TimeoutError' ? 'Pencarian melewati batas waktu. Coba lagi.' : 'Tidak dapat terhubung ke API Detik.' }); }
};
function json(statusCode, body) { return { statusCode, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'access-control-allow-origin': '*', 'access-control-allow-methods': 'GET,OPTIONS', 'access-control-allow-headers': 'Content-Type, Accept' }, body: JSON.stringify(body) }; }
