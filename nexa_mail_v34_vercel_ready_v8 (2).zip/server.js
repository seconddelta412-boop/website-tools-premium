'use strict';
// Demo backend for Nexa Mail AM Premium UI.
// This intentionally does NOT contact Amazon or any third-party activation API.
// Replace handlers only with a service you own or are explicitly authorized to use.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const PORT = Number(process.env.PORT || 3000);
const HTML = path.join(__dirname, 'index.html');
const validEmail = value => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value || '').trim());
function send(res, status, body, type = 'application/json; charset=utf-8') {
  res.writeHead(status, { 'Content-Type': type, 'X-Content-Type-Options': 'nosniff', 'Cache-Control': 'no-store' });
  res.end(type.startsWith('application/json') ? JSON.stringify(body) : body);
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let raw = ''; req.on('data', chunk => { raw += chunk; if (raw.length > 15000) { reject(new Error('Payload too large')); req.destroy(); } });
    req.on('end', () => { try { resolve(JSON.parse(raw || '{}')); } catch { reject(new Error('Invalid JSON')); } });
    req.on('error', reject);
  });
}
const server = http.createServer(async (req, res) => {
  const pathname = new URL(req.url, `http://${req.headers.host || 'localhost'}`).pathname;
  // Serve the current UI and feature scripts from this same origin.
  if (req.method === 'GET' && ['/spotifysearch.js','/safegallery.js','/randommedia.js'].includes(pathname)) {
    try { return send(res, 200, fs.readFileSync(path.join(__dirname, pathname.slice(1)), 'utf8'), 'application/javascript; charset=utf-8'); }
    catch { return send(res, 404, 'Feature script not found', 'text/plain; charset=utf-8'); }
  }
  if (req.method === 'GET' && pathname === '/api/spotify-search') {
    const u = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    const query = String(u.searchParams.get('q') || '').trim().slice(0, 120);
    if (!query) return send(res, 400, {status:false,message:'Masukkan judul lagu atau artis.'});
    try {
      const upstream = new URL('https://www.api-xyurei.my.id/api/search/spotifysearch');
      upstream.searchParams.set('query', query);
      const r = await fetch(upstream, {headers:{accept:'application/json'},signal:AbortSignal.timeout(15000),cache:'no-store'});
      if (!r.ok) return send(res, 502, {status:false,message:`API musik membalas HTTP ${r.status}.`});
      const data = await r.json();
      return send(res, 200, data);
    } catch { return send(res, 502, {status:false,message:'API musik tidak tersedia saat ini.'}); }
  }
  if (req.method === 'GET' && pathname === '/api/random-video') {
    try {
      const upstream = await fetch('https://www.api-xyurei.my.id/api/random/tobrut', {headers:{accept:'video/mp4, application/octet-stream, */*'},redirect:'follow',signal:AbortSignal.timeout(25000),cache:'no-store'});
      if (!upstream.ok || !upstream.body) return send(res, 502, {status:false,message:`Sumber video membalas HTTP ${upstream.status}.`});
      const type = upstream.headers.get('content-type') || 'video/mp4';
      if (!type.includes('video') && !type.includes('octet-stream')) return send(res, 502, {status:false,message:'Sumber tidak mengembalikan file video langsung.'});
      res.writeHead(200, {'Content-Type':type,'Content-Disposition':'inline; filename="nexa-random-video.mp4"','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
      for await (const chunk of upstream.body) res.write(chunk);
      return res.end();
    } catch { return send(res, 502, {status:false,message:'Video gagal diambil dari sumber. Coba lagi nanti.'}); }
  }
  if (req.method === 'GET' && (req.url === '/' || req.url === '/index.html')) {
    try { return send(res, 200, fs.readFileSync(HTML, 'utf8'), 'text/html; charset=utf-8'); }
    catch { return send(res, 500, 'UI file not found', 'text/plain; charset=utf-8'); }
  }
  if (req.method === 'GET' && req.url.split('?')[0] === '/ytsearch.js') {
    try { return send(res, 200, fs.readFileSync(path.join(__dirname, 'ytsearch.js'), 'utf8'), 'application/javascript; charset=utf-8'); }
    catch { return send(res, 404, 'ytsearch.js tidak ditemukan', 'text/plain; charset=utf-8'); }
  }
  if (req.method === 'GET' && req.url.split('?')[0] === '/api/anime') {
    const requestUrl = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    const page = Math.max(1, Math.min(500, Number.parseInt(requestUrl.searchParams.get('page') || '1', 10) || 1));
    const upstreams = [
      { url: 'https://api.nexadev.my.id/anime', kind: 'nexadev' },
      { url: 'https://apii.nexadev.my.id/anime', kind: 'nexadev' },
      { url: 'https://kumanime.vercel.app/api/latest', kind: 'kumanime' }
    ];
    const failures = [];
    for (const item of upstreams) {
      try {
        const upstream = new URL(item.url);
        if (item.kind === 'nexadev') { upstream.searchParams.set('recent', '1'); upstream.searchParams.set('page', String(page)); }
        else upstream.searchParams.set('page', String(page));
        const response = await fetch(upstream.href, { headers: { accept: 'application/json', 'user-agent': 'Mozilla/5.0 NexaAnime/2.0' }, signal: AbortSignal.timeout(10000), cache: 'no-store' });
        let payload; try { payload = JSON.parse(await response.text()); } catch { failures.push(`${upstream.hostname}: respons bukan JSON`); continue; }
        if (!response.ok || payload?.success === false || payload?.status === false) { failures.push(`${upstream.hostname}: HTTP ${response.status}`); continue; }
        const root = payload && typeof payload === 'object' ? payload : {};
        const d = root.data;
        const dataRoot = d && !Array.isArray(d) && typeof d === 'object' ? d : root;
        const candidates = [root, root.animeList, root.result, root.results, root.latest, root.latestAnime, root.latest_release, root.latestRelease, root.ongoing_anime, Array.isArray(d) ? d : null, dataRoot.animeList, dataRoot.result, dataRoot.results, dataRoot.items, dataRoot.list, dataRoot.latest, dataRoot.latest_release, dataRoot.latestRelease, dataRoot.ongoing_anime, root.data?.animeList, root.data?.items, root.data?.list, root.data?.latest];
        const list = candidates.find(Array.isArray) || [];
        const animeList = list.map(a0 => { const a = a0 && typeof a0 === 'object' ? a0 : {}; let link = a.link || a.url || a.animeUrl || a.href || a.animeLink || a.endpoint || a.animeId || a.slug || ''; if (typeof link === 'string' && link.startsWith('/') && item.kind === 'kumanime') link = 'https://kumanime.vercel.app' + link; const typeList = a.typeList && typeof a.typeList === 'object' ? Object.values(a.typeList).filter(Boolean).join(' · ') : ''; return { ...a, title: String(a.title || a.name || a.judul || a.animeTitle || 'Anime tanpa judul'), image: String(a.image || a.poster || a.thumbnail || a.thumb || a.cover || a.img || a.imageUrl || ''), link: String(link || ''), type: String(a.type || a.category || a.statusType || a.status || typeList || 'Anime'), latestEpisode: String(a.latestEpisode || a.episode || a.latest_episode || a.episodeTitle || a.latest || a.release || a.upload_on || 'Episode terbaru') }; }).filter(a => a.title !== 'Anime tanpa judul' || a.image || a.link);
        if (!animeList.length) { failures.push(`${upstream.hostname}: daftar kosong/tidak dikenali`); continue; }
        const total = Number(dataRoot.total || root.total || root.count || root.total_items) || animeList.length;
        const totalPages = Number(dataRoot.totalPages || dataRoot.total_pages || root.totalPages || root.total_pages || root.last_page) || Math.max(page, 1);
        return send(res, 200, { success: true, source: item.kind === 'kumanime' ? 'Kumanime · fallback' : (root.source || root.creator || 'Anime Indo API'), data: { animeList, total, totalPages, page } });
      } catch (error) { failures.push(`${new URL(item.url).hostname}: ${error && error.name === 'TimeoutError' ? 'timeout' : 'koneksi HTTPS gagal'}`); }
    }
    return send(res, 502, { success: false, message: 'Semua server Anime Indo sedang tidak bisa dihubungi. Tekan Coba lagi beberapa saat lagi.', details: failures });
  }
  if (req.method === 'GET' && req.url.split('?')[0] === '/komikusearch.js') {
    try { return send(res, 200, fs.readFileSync(path.join(__dirname, 'komikusearch.js'), 'utf8'), 'application/javascript; charset=utf-8'); }
    catch { return send(res, 404, 'komikusearch.js tidak ditemukan', 'text/plain; charset=utf-8'); }
  }
  if (req.method === 'GET' && req.url.split('?')[0] === '/api/komiku-search') {
    const requestUrl = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    const query = String(requestUrl.searchParams.get('query') || '').trim();
    if (!query) return send(res, 400, { status: false, message: 'Masukkan kata kunci pencarian.' });
    if (query.length > 120) return send(res, 400, { status: false, message: 'Kata kunci terlalu panjang.' });
    try {
      const upstream = new URL('https://www.api-xyurei.my.id/api/komiku/komiku-search');
      upstream.searchParams.set('apikey', process.env.XYUREI_API_KEY || 'xyureifree-b1e0d'); upstream.searchParams.set('query', query);
      const response = await fetch(upstream.href, { headers: { accept: 'application/json' }, signal: AbortSignal.timeout(20000), cache: 'no-store' });
      let data; try { data = await response.json(); } catch { return send(res, 502, { status: false, message: 'API Komiku mengirim respons tidak valid.' }); }
      if (!response.ok || data.status !== true || !Array.isArray(data.data)) return send(res, 502, { status: false, message: data.message || `API Komiku gagal (HTTP ${response.status}).` });
      const results = data.data.filter(x => x && typeof x.slug === 'string' && x.slug.trim()).map(x => ({ slug: x.slug.trim(), chapter: String(x.chapter || '1').trim() })).slice(0, 50);
      return send(res, 200, { status: true, total: Number(data.total) || results.length, data: results });
    } catch (error) { return send(res, 502, { status: false, message: error && error.name === 'TimeoutError' ? 'Pencarian terlalu lama. Coba lagi.' : 'Tidak dapat terhubung ke API Komiku.' }); }
  }
  if (req.method === 'GET' && req.url.split('?')[0] === '/detiksearch.js') {
    try { return send(res, 200, fs.readFileSync(path.join(__dirname, 'detiksearch.js'), 'utf8'), 'application/javascript; charset=utf-8'); }
    catch { return send(res, 404, 'detiksearch.js tidak ditemukan', 'text/plain; charset=utf-8'); }
  }
  if (req.method === 'GET' && req.url.split('?')[0] === '/api/detik-search') {
    const requestUrl = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    const q = String(requestUrl.searchParams.get('q') || '').trim();
    if (!q) return send(res, 400, { status: false, message: 'Masukkan kata kunci berita.' });
    if (q.length > 120) return send(res, 400, { status: false, message: 'Kata kunci terlalu panjang.' });
    try {
      const upstream = new URL('https://www.api-xyurei.my.id/api/news/detiksearch');
      upstream.searchParams.set('apikey', process.env.XYUREI_API_KEY || 'xyureifree-b1e0d'); upstream.searchParams.set('q', q);
      const response = await fetch(upstream.href, { headers: { accept: 'application/json' }, signal: AbortSignal.timeout(20000), cache: 'no-store' });
      let data; try { data = await response.json(); } catch { return send(res, 502, { status: false, message: 'API Detik mengirim respons tidak valid.' }); }
      if (!response.ok || data.status !== true || !Array.isArray(data.result)) return send(res, 502, { status: false, message: data.message || `API Detik gagal (HTTP ${response.status}).` });
      const result = data.result.filter(x => x && typeof x.title === 'string' && typeof x.url === 'string').map(x => { let url = ''; try { const u = new URL(x.url); if (u.protocol === 'https:' && (u.hostname === 'detik.com' || u.hostname.endsWith('.detik.com'))) url = u.href; } catch {} let image = ''; try { const u = new URL(x.image || ''); if (u.protocol === 'https:') image = u.href; } catch {} return { no: Number(x.no) || 0, title: String(x.title).slice(0,400), time: String(x.time || '').slice(0,100), url, image, category: String(x.category || 'Detik').slice(0,80) }; }).filter(x => x.url).slice(0,50);
      return send(res, 200, { status: true, creator: String(data.creator || ''), total: Number(data.total) || result.length, result });
    } catch (error) { return send(res, 502, { status: false, message: error && error.name === 'TimeoutError' ? 'Pencarian melewati batas waktu. Coba lagi.' : 'Tidak dapat terhubung ke API Detik.' }); }
  }
  if (req.method === 'GET' && req.url.split('?')[0] === '/flaggame.js') {
    try { return send(res, 200, fs.readFileSync(path.join(__dirname, 'flaggame.js'), 'utf8'), 'application/javascript; charset=utf-8'); }
    catch { return send(res, 404, 'flaggame.js tidak ditemukan', 'text/plain; charset=utf-8'); }
  }
  if (req.method === 'GET' && req.url.split('?')[0] === '/api/flag-game') {
    try {
      const response = await fetch('https://www.api-xyurei.my.id/api/game/tebakbenderav1', { headers: { accept: 'application/json' }, signal: AbortSignal.timeout(15000), cache: 'no-store' });
      let data; try { data = await response.json(); } catch { return send(res, 502, { status: false, message: 'API game mengirim respons yang tidak valid.' }); }
      const item = data && data.result;
      if (!response.ok || data.status !== true || !item || typeof item.name !== 'string' || typeof item.img !== 'string') return send(res, 502, { status: false, message: data.message || `API game tidak tersedia (HTTP ${response.status}).` });
      let imageUrl; try { imageUrl = new URL(item.img); } catch { return send(res, 502, { status: false, message: 'URL gambar bendera dari API tidak valid.' }); }
      if (imageUrl.protocol !== 'https:') return send(res, 502, { status: false, message: 'Gambar bendera harus menggunakan HTTPS.' });
      return send(res, 200, { status: true, creator: data.creator || 'Xyurei', result: { flag: String(item.flag || ''), img: imageUrl.href, name: item.name.trim() } });
    } catch (error) { return send(res, 502, { status: false, message: error && error.name === 'TimeoutError' ? 'Server game terlalu lama merespons. Coba lagi.' : 'Tidak dapat terhubung ke API game. Coba lagi beberapa saat.' }); }
  }
  if (req.method === 'GET' && req.url.split('?')[0] === '/webcheck.js') {
    try { return send(res, 200, fs.readFileSync(path.join(__dirname, 'webcheck.js'), 'utf8'), 'application/javascript; charset=utf-8'); }
    catch { return send(res, 404, 'webcheck.js tidak ditemukan', 'text/plain; charset=utf-8'); }
  }
  if (req.method === 'GET' && req.url.split('?')[0] === '/ytdownload.js') {
    try { return send(res, 200, fs.readFileSync(path.join(__dirname, 'ytdownload.js'), 'utf8'), 'application/javascript; charset=utf-8'); }
    catch { return send(res, 404, 'ytdownload.js tidak ditemukan', 'text/plain; charset=utf-8'); }
  }
  if (req.method === 'GET' && req.url.split('?')[0] === '/api/yt-download') {
    const requestUrl = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    const videoUrl = String(requestUrl.searchParams.get('url') || '').trim();
    const type = String(requestUrl.searchParams.get('type') || 'video').toLowerCase();
    const quality = String(requestUrl.searchParams.get('quality') || '720p').toLowerCase();
    let parsed; try { parsed = new URL(videoUrl); } catch { return send(res, 400, {status:false,message:'Masukkan URL YouTube yang valid.'}); }
    if (!['youtube.com','www.youtube.com','m.youtube.com','youtu.be','www.youtu.be'].includes(parsed.hostname) || !['http:','https:'].includes(parsed.protocol)) return send(res, 400, {status:false,message:'URL harus berasal dari YouTube atau youtu.be.'});
    if (!['video','audio'].includes(type) || !['360p','720p','1080p'].includes(quality)) return send(res, 400, {status:false,message:'Pilih tipe media dan kualitas yang tersedia.'});
    const upstream = new URL('https://api.nexadev.my.id/api/ytmp4'); upstream.searchParams.set('url',parsed.href); upstream.searchParams.set('type',type); upstream.searchParams.set('quality',quality);
    try { const response=await fetch(upstream.href,{headers:{accept:'application/json'},signal:AbortSignal.timeout(45000),cache:'no-store'}); const raw=await response.text(); let data; try{data=JSON.parse(raw)}catch{return send(res,502,{status:false,message:'API downloader mengirim respons tidak valid.'})} if(!response.ok||data.status!==true||!data.data||!data.data.url)return send(res,502,{status:false,message:data.message||`API downloader gagal (HTTP ${response.status}).`}); return send(res,200,data); }
    catch { return send(res,502,{status:false,message:'Tidak dapat terhubung ke API downloader.'}); }
  }
  if (req.method === 'GET' && req.url.split('?')[0] === '/api/web-check') {
    const requestUrl = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    const rawUrl = String(requestUrl.searchParams.get('url') || '').trim();
    let target;
    try { target = new URL(rawUrl); } catch { return send(res, 400, { status: false, message: 'Masukkan URL website yang valid.' }); }
    if (!['http:', 'https:'].includes(target.protocol) || target.username || target.password || target.hostname === 'localhost' || target.hostname.endsWith('.local')) return send(res, 400, { status: false, message: 'Gunakan URL website publik dengan HTTP atau HTTPS.' });
    if (rawUrl.length > 2048) return send(res, 400, { status: false, message: 'URL terlalu panjang.' });
    try {
      const upstream = new URL('https://www.api-xyurei.my.id/api/tools/web-check');
      upstream.searchParams.set('apikey', process.env.WEB_CHECK_API_KEY || 'xyureifree-b1e0d');
      upstream.searchParams.set('url', target.href);
      const response = await fetch(upstream.href, { headers: { accept: 'application/json' }, signal: AbortSignal.timeout(25000), cache: 'no-store' });
      const raw = await response.text();
      let data; try { data = JSON.parse(raw); } catch { return send(res, 502, { status: false, message: 'API Web Check mengirim respons yang tidak valid.' }); }
      if (!response.ok || data.status !== true || !data.result || typeof data.result !== 'object') return send(res, 502, { status: false, message: data.message || `API Web Check gagal (HTTP ${response.status}).` });
      return send(res, 200, data);
    } catch (error) { return send(res, 502, { status: false, message: error && error.name === 'TimeoutError' ? 'Pemeriksaan melewati batas waktu. Coba lagi.' : 'Tidak dapat terhubung ke API Web Check.' }); }
  }
  if (req.method === 'GET' && req.url.split('?')[0] === '/api/ytsearch') {
    const requestUrl = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    const query = String(requestUrl.searchParams.get('q') || '').trim();
    if (!query) return send(res, 400, { status: false, message: 'Parameter q wajib diisi.' });
    if (query.length > 200) return send(res, 400, { status: false, message: 'Kata kunci terlalu panjang.' });
    try {
      const upstream = new URL('https://api.nexadev.my.id/tools/ytsearch');
      upstream.searchParams.set('q', query);
      const response = await fetch(upstream.href, { headers: { accept: 'application/json' }, signal: AbortSignal.timeout(20000), cache: 'no-store' });
      const raw = await response.text();
      let data;
      try { data = JSON.parse(raw); } catch { return send(res, 502, { status: false, message: 'API YouTube Search mengembalikan respons tidak valid.' }); }
      if (!response.ok || data.status !== true || !Array.isArray(data.result)) return send(res, 502, { status: false, message: 'API YouTube Search sedang tidak tersedia.' });
      return send(res, 200, data);
    } catch { return send(res, 502, { status: false, message: 'Tidak dapat terhubung ke API YouTube Search.' }); }
  }
  if (req.method === 'GET' && req.url === '/health') return send(res, 200, { status: true, mode: 'demo', message: 'Backend demo aktif.' });
  if (req.method !== 'POST' || !['/api/am/send', '/api/am/verif'].includes(req.url)) return send(res, 404, { status: false, message: 'Route tidak ditemukan.' });
  const started = Date.now();
  try {
    const body = await readBody(req);
    const email = String(body.email || '').trim().toLowerCase();
    if (!validEmail(email)) return send(res, 400, { status: false, message: 'Alamat email tidak valid.' });
    if (req.url === '/api/am/verif') {
      let parsed;
      try { parsed = new URL(String(body.link || '')); } catch { return send(res, 400, { status: false, message: 'URL verifikasi tidak valid.' }); }
      if (!['http:', 'https:'].includes(parsed.protocol)) return send(res, 400, { status: false, message: 'URL harus menggunakan HTTP atau HTTPS.' });
      // Never fetch or follow the submitted URL; verification links can contain secret tokens.
      return send(res, 200, { status: true, creator: 'Nexa Mail', response_time: `${Date.now() - started}ms`, statusCode: 200, message: 'URL dicatat untuk demo saja. Tidak ada verifikasi atau aktivasi premium yang dilakukan.', result: { email, status: 'Demo: menunggu verifikasi resmi' }, timestamp: new Date().toISOString() });
    }
    return send(res, 200, { status: true, creator: 'Nexa Mail', response_time: `${Date.now() - started}ms`, statusCode: 200, message: 'Permintaan dicatat untuk demo saja. Tidak ada email yang dikirim.', request_id: crypto.randomUUID(), result: { email, status: 'Demo: permintaan dicatat lokal' }, timestamp: new Date().toISOString() });
  } catch (err) {
    return send(res, 400, { status: false, message: err.message === 'Payload too large' ? 'Data terlalu besar.' : 'JSON tidak valid.' });
  }
});
server.listen(PORT, () => console.log(`Nexa Mail demo backend: http://localhost:${PORT}`));
