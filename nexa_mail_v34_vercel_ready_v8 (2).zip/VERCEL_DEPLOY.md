# Deploy Nexa Mail to Vercel

1. Upload this project to a Git repository or import the project into Vercel.
2. Use the project root as the Root Directory.
3. Framework Preset: Other.
4. Build Command: leave empty; Output Directory: `.` (static HTML project).
5. Runtime: Node.js 18 or newer.
6. Deploy. `index.html` is the main page and must remain at the project root.

## API routes

`api/[...path].js` adapts the existing Netlify-style serverless handlers to Vercel's Node.js request/response format. Supported routes include `/api/media-tools`, `/api/spotify-search`, `/api/anime`, `/api/yt-download`, `/api/detik-search`, `/api/flag-game`, `/api/web-check`, `/api/apilist`, `/api/ytsearch`, `/api/age-verification`, `/api/am-premium`, and `/api/am-confirm`.

Configure `XYUREI_API_KEY` and `NEXADEV_API_KEY` in Vercel Project Settings → Environment Variables if you use your own keys. The project may still rely on third-party API availability, CORS policies, and upstream response formats. A successful deployment does not guarantee every external API is online.

`index.html` is the main website entry point. The redundant standalone `nexa_mail_iphone_am_prem_ui.html` was removed; `index.html` was preserved.
