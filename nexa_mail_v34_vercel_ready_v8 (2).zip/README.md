# Nexa Mail AM Prem — Netlify deploy

## Fitur AM Premium dan perbaikan JavaScript
- Tombol kirim memanggil `/.netlify/functions/am-premium`, yang meneruskan ke API `/am/send/`.
- Tombol verifikasi memanggil `/.netlify/functions/am-confirm`, yang meneruskan ke API `/am/verif/`.
- Memperbaiki deklarasi fungsi frontend menjadi `async` agar pemanggilan `fetch` dengan `await` tidak membuat seluruh skrip gagal dijalankan.

## Perbaikan Page Not Found
- `index.html` sekarang berada di root publish directory.
- Netlify Functions berada di folder `function/` (singular), sesuai konfigurasi `netlify.toml`.
- Nama endpoint publik tetap:
  - `/.netlify/functions/am-premium`
  - `/.netlify/functions/am-confirm`

## Deploy ke Netlify
1. Ekstrak ZIP ini dan unggah isi folder `nexa_am_prem_package` sebagai deploy manual, atau hubungkan folder ini sebagai project.
2. Pastikan `netlify.toml` dan `index.html` ada di root deploy yang sama.
3. Di Netlify Site configuration → Environment variables, tambahkan `NEXADEV_API_KEY` dengan key yang valid. Jangan menulis key di HTML atau repo.
4. Deploy ulang (jangan hanya refresh browser).
5. Tes halaman utama `/`, lalu tes fungsi melalui formulir website.

## Catatan
Fungsi ini meneruskan permintaan ke API NexaDev `/am/send/` dan `/am/verif/`. Penggunaan API upstream bergantung pada akses, kuota, dan izin dari pemiliknya. Jangan bagikan URL verifikasi yang mengandung token autentikasi.


## AM Premium API (sudah diintegrasikan)
- Kirim link: `/.netlify/functions/am-premium` → `https://api.nexadev.my.id/am/send/`
- Verifikasi link: `/.netlify/functions/am-confirm` → `https://api.nexadev.my.id/am/verif/`
- Form UI di `index.html` sudah memanggil kedua function tersebut.
- Disarankan mengatur `NEXADEV_API_KEY` pada Netlify Environment Variables; fallback key server-side hanya untuk kemudahan paket ini. Jangan menaruh API key di HTML/frontend.

## YouTube Search
- UI JavaScript: `ytsearch.js`.
- Endpoint frontend: `/api/ytsearch?q=karna%20kamu`.
- Netlify route: `/api/ytsearch` → `/.netlify/functions/yt-search`.
- Netlify Function: `function/yt-search.js`, meneruskan query ke `https://api.nexadev.my.id/tools/ytsearch?q=...` di sisi server.
- Jika menjalankan `npm start`, route `/api/ytsearch` dan file `ytsearch.js` juga dilayani oleh `server.js`.

### Anime Indo di Netlify

Anime Terbaru sekarang memanggil endpoint satu-origin `/api/anime?page=1`. Netlify mengarahkan request tersebut ke `function/anime.js`, yang mencoba `https://api.nexadev.my.id/anime`, lalu `https://apii.nexadev.my.id/anime`, dan memakai `https://kumanime.vercel.app/api/latest` sebagai fallback terakhir. Proxy juga menormalkan beberapa bentuk respons API sehingga perubahan format data tidak langsung merusak tampilan. Pastikan `netlify.toml` dan folder `function/` ikut diunggah ke Netlify; jangan hanya unggah file HTML.


### YouTube Downloader
- Buka menu **YouTube Downloader**, tempel URL YouTube, lalu pilih Video/Audio dan kualitas.
- Frontend memanggil endpoint same-origin `/api/yt-download`; Netlify meneruskannya ke `function/yt-download.js` agar tidak bergantung pada CORS browser.
- Endpoint upstream: `https://api.nexadev.my.id/api/ytmp4`. Tautan akhir disediakan oleh API pihak ketiga dan dapat kedaluwarsa.


## Check Web
- Menu `Check Web` memeriksa HTTP status, SEO metadata, robots, canonical, mobile hints, tautan, gambar, dan assets melalui API Web Check Xyurei.
- Browser memanggil endpoint same-origin `/api/web-check?url=...`; Netlify mengarahkannya ke `function/web-check.js`.
- API key disimpan di Function. Untuk mengganti key, set environment variable `WEB_CHECK_API_KEY` di Netlify/local environment.
- Deploy ke Netlify dengan `netlify.toml` dan folder `function` tetap berada di root proyek.


## Game Tebak Bendera
Fitur Tebak Bendera memakai proxy `GET /api/flag-game` yang meneruskan permintaan ke API Xyurei `https://www.api-xyurei.my.id/api/game/tebakbenderav1`. Untuk Netlify, deploy folder `function` bersama `netlify.toml`. Untuk server lokal, gunakan Node.js 18+ dan `npm start`.


### Search Komiku
Fitur Search Komiku memakai endpoint internal `/api/komiku-search?query=...` yang mem-proxy API Xyurei. Untuk Netlify, deploy folder ini beserta `function/komiku-search.js` dan `netlify.toml`. Untuk server Node lokal, jalankan `npm start`. API key dapat dioverride dengan environment variable `XYUREI_API_KEY`.


## Komik Indo dan Komiku Search
- **Komik Indo** adalah menu reader chapter terpisah yang menggunakan endpoint reader Komikindo yang sudah ada.
- **Komiku Search** adalah menu pencarian terpisah yang menggunakan API `/api/komiku-search?query=...`. Hasil pencarian menyediakan tombol salin slug dan tidak mengirim slug Komiku ke reader Komik Indo, karena keduanya merupakan layanan berbeda.
- Pastikan `function/komiku-search.js` dan redirect `/api/komiku-search` tetap disertakan saat deploy ke Netlify.


## Detik Search
Menu Detik Search menyediakan pencarian berita melalui endpoint `/api/detik-search?q=...`. Untuk Netlify, fungsi backend berada di `function/detik-search.js` dan route-nya dikonfigurasi di `netlify.toml`. Untuk server Node, route tersedia pada `server.js`. Kunci API dapat diatur lewat variabel lingkungan `XYUREI_API_KEY`.

## Random Video (API Xyurei)
Menu `Random Video` menambahkan pratinjau video dari `https://www.api-xyurei.my.id/api/random/tobrut`. Video dibuat non-interaktif (tanpa kontrol dan tidak menerima klik), dengan tombol unduhan terpisah di bawahnya. Pratinjau/unduhan mengikuti format respons dan kebijakan CORS endpoint sumber; jika endpoint hanya mengembalikan JSON metadata, browser tidak dapat mengunduh media yang tidak disertakan dalam respons.

## Nexa Tools update (V28)

- Spotify Search: frontend calls `/api/spotify-search`; upstream `apikey` is added in the Netlify function (configure `XYUREI_API_KEY` in Netlify environment variables for production).
- New `/api/media-tools` Netlify function proxies an allowlist of Translate, Meme Search, Quran Surah List, Komiku Chapter Images, and IQC image generation endpoints.
- New `tools.js` powers the Translator, Meme Search, IQC WhatsApp image maker, Al-Qur'an Surah list (114 entries), and Komiku Chapter screens.
- API endpoints and keys are kept out of browser JavaScript; requests go through Netlify Functions. Set `XYUREI_API_KEY` in Netlify > Site configuration > Environment variables. A demo fallback key remains in the function for compatibility; replace it with your own secret in production.
- Random Video continues to use `function/random-video.js` through the existing proxy.
- The unknown `/api/random/loli` endpoint and `/api/random/animehot` are intentionally not wired in because the returned media cannot be verified as safe. Use Anime Gallery SFW for safe anime art instead.
- Some upstream endpoints may return metadata instead of actual media bytes, or no chapter images. The UI reports this rather than fabricating images. Live API responses were not verified in this build environment.

## Verifikasi usia & persetujuan admin (V29)
- Pengajuan usia menggunakan `POST /api/age-verification` dan status/review disimpan di Netlify Blobs, bukan `localStorage`.
- Endpoint galeri yang dibatasi diproksi melalui `GET /api/age-media`; status `approved` diverifikasi di server pada setiap permintaan. Mengubah UI/browser tidak memberi akses tanpa status server yang disetujui.
- Set environment variable `AGE_ADMIN_KEY` ke kunci acak panjang di Netlify. Admin masuk ke Admin Panel, isi kunci server tersebut, lalu muat daftar pengajuan dan pilih Setujui/Tolak.
- Pastikan Netlify Blobs tersedia di site yang di-deploy. Jika belum, fungsi mengembalikan pesan konfigurasi dan akses tetap terkunci.
- Form tidak mengambil atau mengunggah foto wajah. Konfirmasi usia mandiri + persetujuan admin bukan verifikasi umur yang kuat; untuk produksi gunakan penyedia verifikasi usia tepercaya.
- Endpoint `/api/random/loli` dan `/api/random/animehot` tetap tidak diaktifkan karena isi media upstream belum dapat dipastikan aman, khususnya risiko karakter yang tampak di bawah umur. Gate ini tidak membuka endpoint tersebut.


## V31 — Modern feature key gate
- Added a modern masked-key dialog (key: `1998`) before entering Anime Gallery, then existing server-side age/admin approval remains required.
- The key is a client-side UI gate and can be discovered by inspecting JavaScript; do not treat it as strong security. Real protection comes from server-side age approval.
- `/api/random/loli` and `/api/random/animehot` remain intentionally disabled: upstream content cannot be verified as safe, including risk of sexualized underage-looking characters. The gallery continues to use SFW anime art.

## V33 — Anime Indo search / HTTP 403 handling
- Pencarian Anime Indo sekarang mengirim query ke fungsi server dan tidak hanya memfilter kartu yang sudah tampil.
- Request katalog memakai `cache: no-store` agar hasil pencarian tidak tertahan cache lama.
- Link streaming hanya dibuka bila upstream memberikan URL HTTP/HTTPS yang valid.
- HTTP 403 dari host streaming tidak dibypass. 403 adalah penolakan dari server/CDN sumber; aplikasi tidak mencoba mengakali autentikasi, referer ACL, signed URL, atau pembatasan IP. Bila sumber mengganti/menolak URL, gunakan URL baru yang memang diizinkan oleh provider.


## V34 — Feature cleanup
Removed Random Video/Tobrut, Komik Indo, Komiku Search, Komiku Chapter, Anime Gallery, and Anime Gallery SFW from the UI and their dedicated routes/files where applicable.

## Fitur Islam & utilitas baru (versi UI hitam-putih)

- Daftar Surah menggunakan `https://www.api-xyurei.my.id/api/islam/listsurah`.
- Bacaan Shalat menggunakan `https://www.api-xyurei.my.id/api/islam/bacaanshalat`.
- Tebak Kabupaten menggunakan `https://www.api-xyurei.my.id/api/game/tebakkabupaten`.
- Screenshot Web menggunakan endpoint `/api/tools/ssweb` dalam mode `desktop`.
- YouTube Play menggunakan endpoint `/api/search/ytplay`; tombol hasil mengarah ke video YouTube resmi.

Semua request fitur di atas diproxy melalui Netlify Function `function/media-tools.js`. API key untuk endpoint yang membutuhkannya dibaca dari environment variable `XYUREI_API_KEY`; jika tidak disetel, proxy menggunakan key free publik yang tercantum pada contoh API. Untuk deployment produksi, setel `XYUREI_API_KEY` di Site configuration → Environment variables, lalu redeploy.
