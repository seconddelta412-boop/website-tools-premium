// Vercel adapter for the existing Netlify-style handlers.
// Keeps the frontend's /api/* URLs compatible without changing index.html.
const routes = {
  'media-tools': '../function/media-tools.js',
  'spotify-search': '../function/spotify-search.js',
  'anime': '../function/anime.js',
  'yt-download': '../function/yt-download.js',
  'detik-search': '../function/detik-search.js',
  'flag-game': '../function/flag-game.js',
  'web-check': '../function/web-check.js',
  'apilist': '../function/apilist.js',
  'ytsearch': '../function/yt-search.js',
  'age-verification': '../function/age-verification.js',
  'am-premium': '../function/am-premium.js',
  'am-confirm': '../function/am-confirm.js'
};

module.exports = async function vercelApi(req, res) {
  const raw = req.query?.path;
  const parts = Array.isArray(raw) ? raw : (raw ? [raw] : []);
  const route = parts[0] || '';
  const modulePath = routes[route];
  if (!modulePath) {
    res.setHeader('Cache-Control', 'no-store');
    return res.status(404).json({ status: false, message: `Endpoint API tidak ditemukan: /api/${route}` });
  }
  try {
    const mod = require(modulePath);
    const handler = mod.handler || mod.default;
    if (typeof handler !== 'function') throw new Error('Handler API tidak valid');
    const queryStringParameters = {};
    for (const [key, value] of Object.entries(req.query || {})) {
      if (key === 'path') continue;
      queryStringParameters[key] = Array.isArray(value) ? value[0] : value;
    }
    let body = '';
    if (req.body !== undefined && req.body !== null) {
      body = typeof req.body === 'string' ? req.body : JSON.stringify(req.body);
    }
    const event = {
      httpMethod: req.method || 'GET',
      path: req.url || `/api/${route}`,
      headers: req.headers || {},
      queryStringParameters,
      body,
      isBase64Encoded: false
    };
    const result = await handler(event, {});
    const statusCode = Number(result?.statusCode) || 200;
    for (const [key, value] of Object.entries(result?.headers || {})) {
      if (value !== undefined && value !== null) res.setHeader(key, value);
    }
    if (result?.isBase64Encoded && typeof result.body === 'string') {
      return res.status(statusCode).send(Buffer.from(result.body, 'base64'));
    }
    if (result?.body === undefined || result.body === null || result.body === '') return res.status(statusCode).end();
    const contentType = String(result.headers?.['content-type'] || '');
    if (contentType.includes('application/json')) {
      try { return res.status(statusCode).send(JSON.parse(result.body)); }
      catch { return res.status(statusCode).send(result.body); }
    }
    return res.status(statusCode).send(result.body);
  } catch (error) {
    console.error('Vercel API adapter error:', route, error?.message || error);
    return res.status(500).json({ status: false, message: 'Terjadi kesalahan internal pada endpoint API.' });
  }
};
