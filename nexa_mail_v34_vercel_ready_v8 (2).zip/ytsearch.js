/* YouTube Search UI. API proxy endpoint: /api/ytsearch?q=... */
(function () {
  'use strict';
  const el = id => document.getElementById(id);
  const API_ENDPOINT = '/api/ytsearch';
  let loading = false;

  function safeHttpUrl(value, hosts) {
    try {
      const url = new URL(String(value || ''));
      if (url.protocol !== 'https:' && url.protocol !== 'http:') return '';
      if (hosts && !hosts.some(host => url.hostname === host || url.hostname.endsWith('.' + host))) return '';
      return url.href;
    } catch (_) { return ''; }
  }

  function renderYouTube(results) {
    const root = el('ytGrid');
    if (!root) return;
    root.replaceChildren();
    if (!results.length) {
      root.innerHTML = '<div class="yt-empty">Tidak ada video ditemukan.<br>Coba kata kunci lain.</div>';
      return;
    }
    results.forEach(item => {
      const link = safeHttpUrl(item.link, ['youtube.com', 'youtu.be', 'm.youtube.com']);
      const card = document.createElement(link ? 'a' : 'article');
      card.className = 'yt-card';
      if (link) {
        card.href = link; card.target = '_blank'; card.rel = 'noopener noreferrer';
        card.setAttribute('aria-label', 'Buka ' + String(item.title || 'video') + ' di YouTube');
      }
      const thumb = document.createElement('div'); thumb.className = 'yt-thumb';
      const img = document.createElement('img'); img.loading = 'lazy'; img.alt = String(item.title || 'Thumbnail video YouTube');
      img.src = safeHttpUrl(item.imageUrl, ['i.ytimg.com']) || '';
      img.onerror = () => { img.style.display = 'none'; thumb.style.background = 'linear-gradient(135deg,#3a2027,#17171a)'; };
      thumb.append(img);
      const play = document.createElement('span'); play.className = 'yt-play'; play.textContent = '▶'; play.setAttribute('aria-hidden', 'true'); thumb.append(play);
      if (item.duration) { const duration = document.createElement('span'); duration.className = 'yt-duration'; duration.textContent = String(item.duration); thumb.append(duration); }
      const copy = document.createElement('div'); copy.className = 'yt-card-copy';
      const title = document.createElement('strong'); title.className = 'yt-title'; title.textContent = String(item.title || 'Video tanpa judul');
      const channel = document.createElement('div'); channel.className = 'yt-channel'; channel.textContent = String(item.channel || 'Channel YouTube');
      const open = document.createElement('div'); open.className = 'yt-open'; open.textContent = 'Tonton di YouTube ↗';
      copy.append(title, channel, open); card.append(thumb, copy); root.append(card);
    });
  }

  async function searchYouTube() {
    if (loading) return;
    const input = el('ytSearchInput');
    const query = String(input && input.value || '').trim();
    if (!query) { el('ytStatus').textContent = 'Masukkan kata kunci terlebih dahulu.'; if (input) input.focus(); return; }
    loading = true;
    el('ytStatus').textContent = 'Sedang mencari video…';
    el('ytResultCount').textContent = 'Mencari…';
    const submit = el('ytSearchForm') && el('ytSearchForm').querySelector('button[type="submit"]');
    if (submit) { submit.disabled = true; submit.style.opacity = '.65'; }
    try {
      const url = new URL(API_ENDPOINT, window.location.origin);
      url.searchParams.set('q', query);
      const response = await fetch(url.href, { headers: { Accept: 'application/json' }, cache: 'no-store' });
      if (!response.ok) throw new Error('HTTP ' + response.status);
      const json = await response.json();
      if (json.status !== true || !Array.isArray(json.result)) throw new Error('Format respons API tidak sesuai');
      el('ytResultCount').textContent = json.result.length + ' video ditemukan';
      el('ytResultSource').textContent = 'Sumber: ' + String(json.author || 'NexaDev');
      el('ytStatus').textContent = 'Hasil pencarian untuk “' + query + '”';
      renderYouTube(json.result);
    } catch (_) {
      el('ytResultCount').textContent = 'Hasil belum tersedia';
      el('ytStatus').textContent = 'Pencarian YouTube gagal dimuat. Periksa koneksi atau konfigurasi API, lalu coba lagi.';
      const grid = el('ytGrid');
      grid.innerHTML = '<div class="yt-empty">Tidak dapat memuat hasil.<br><button id="ytRetry" type="button" class="pill blue" style="margin-top:12px;padding:9px 15px">Coba lagi</button></div>';
      el('ytRetry').addEventListener('click', searchYouTube);
    } finally {
      loading = false;
      if (submit) { submit.disabled = false; submit.style.opacity = ''; }
    }
  }

  window.searchYouTube = searchYouTube;
  el('ytSearchForm')?.addEventListener('submit', event => { event.preventDefault(); searchYouTube(); });
  el('ytRefresh')?.addEventListener('click', searchYouTube);
  el('ytBack')?.addEventListener('click', () => {
    if (typeof window.go === 'function') window.go('home');
    else document.querySelectorAll('.screen').forEach(screen => screen.classList.toggle('active', screen.id === 'screen-home'));
  });
})();
